# Aviator Predictor v29 — Welcome Splash Screen

Version 29 is based on the Version 28 hybrid capture/OCR/cloud-sync source. This update adds a native, programmatically rendered welcome screen that appears on each cold app launch for approximately three seconds before the existing dashboard initializes.

## Welcome screen details
- Sporty red/black background with white typography and green/gold accent bars.
- Aviator emblem and sports/live-game/analytics branding.
- Exact credit: **DEVELOPED BY — Ebiwari Sunshine Pereyei O.**
- Automatic transition to the existing app after 3 seconds.
- Main app initialization starts after the welcome interval; existing capture, OCR, history, model, and cloud-sync code is retained.

## Build
Run `gradle --no-daemon assembleDebug` with Android SDK platform 35 and build-tools installed. The included GitHub Actions workflow also builds the debug APK when the source is pushed to a repository and the workflow is run.


Cloud synchronization repair notes are in `README_V29_CLOUD_SYNC_FIX.md`. The matching authenticated read endpoint is included under `supabase/functions/aviator-sync/`.
