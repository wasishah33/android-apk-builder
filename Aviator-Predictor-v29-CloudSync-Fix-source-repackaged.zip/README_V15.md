# Aviator AI Live Analyzer v15

Default SportyBet Aviator URL updated to:
https://www.sportybet.com/ng/m/games/spribe/aviator

This release is based on v14 Capture Fixed and retains its live-capture safeguards, including main-page/iframe source separation, changing-candidate tracking, stale-reading protection, and the NO FRESH LIVE READING watchdog. The analyzer does not guarantee or claim to predict random crash outcomes.
