# Aviator AI v22 — Google ML Kit OCR integration

This source adds Google ML Kit Latin Text Recognition to the existing tested v21 frame-capture app.

## Why ML Kit

The app needs fast OCR on Android-rendered bitmaps, with text boxes/lines so it can isolate a row of historical multipliers. ML Kit directly accepts a `Bitmap`, runs on-device, and the bundled dependency includes the OCR model. It avoids needing to download model data on first use and does not require a cloud OCR API key. The trade-off is a larger APK.

## OCR flow

- Samples the visible WebView at up to 960 px wide.
- Sends at most one bitmap to OCR at a time, with a ~700 ms OCR interval to limit CPU and memory pressure.
- Reads ML Kit text lines and looks for 3–35 multiplier-like tokens on a single line.
- Sends only that candidate line to the existing history-row prefix-difference logic. A lone large live multiplier is not sent to history learning.
- Displays frame count, OCR count, candidate-row count, last OCR decision and recognized text in the diagnostics.
- Frames are processed in memory and recycled; no video or screenshots are persisted.

## Build

Requirements: JDK 17, Gradle 8.9+, Android SDK platform/build tools 35, and network access to Google's Maven repository and Maven Central.

Run:

```sh
./build_ocr_apk.sh
```

Output: `dist/AviatorAI_LiveAnalyzer_v22_MLKit_OCR.apk`.

The previous custom Gradle-less `build_apk.sh` cannot build this OCR version because ML Kit and its transitive Android dependencies must be resolved through Gradle. It is retained only for historical reference and must not be used for v22.

## Known limitation

OCR row selection is a heuristic: it currently requires at least three multiplier tokens on the same OCR text line. If the game's history row is broken into separate OCR lines or uses very small text, tune the region/line grouping using a real screenshot from the target device. OCR output must be visually validated before relying on it for any analysis. Multiplier estimates are statistical, not guarantees.
