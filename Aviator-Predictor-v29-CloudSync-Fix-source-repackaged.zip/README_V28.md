# Aviator Predictor v28 — source package

Version 28 is based on the available v26 source review package that was used as the source baseline for the v27 APK.

## Changes in this package
- Android version code/name: `28` / `28.0-Hybrid-Capture-Sports-UI`.
- Keep-screen-awake while the Activity is visible; clear the flag in `onStop()` so normal timeout behavior resumes when leaving the app.
- Persistent local prediction ledger: each materially different estimate revision is timestamped with target round index, central estimate, lower/upper band, source and model version.
- Outcome evaluation: match an actual completed round to predictions made for that exact target index; store absolute/relative error and band-covered/outside-band status without overwriting the saved prediction values.
- Local online learning remains offline-capable and is updated from completed outcomes; observation queue is persisted for later cloud sync.
- Honest chronological walk-forward replay and bounded diagnostic history window to reduce long-session slowdown while preserving the full stored round history (up to the app's existing cap).
- Cloud re-evaluation endpoint `aviator-reestimate` deployed to the configured Supabase project. It evaluates the same submitted recent history and only returns a candidate as validated if it has at least 20 holdout samples and beats the local walk-forward MAE by at least 2%. The app verifies target round index and history fingerprint before applying a cloud revision; stale results are ignored. Failed cloud attempts are retried while the app remains open.
- Cloud observation ingestion continues to queue readings for authenticated sync; the backend currently marks observations pending validation rather than treating raw OCR as confirmed outcomes.

## Important limitations / build status
- The cloud re-estimation endpoint is active, but cross-device shared model training and centralized prediction-snapshot storage are **not** fully implemented in this package. Cloud re-estimation currently evaluates the same recent history supplied by this device; it is not a guarantee of better predictions.
- The Java source passed basic delimiter checks and `javac` reported no Java syntax diagnostics before stopping on missing Android/JSON SDK classes. It has **not** been compiled against the Android SDK, installed, or launched on a device here.
- No new APK has been built or verified in this environment. Do not treat this source ZIP as an installable APK.
- Crash-game outcomes are inherently unpredictable; the estimates and metrics are experimental and do not guarantee accuracy or winnings.
