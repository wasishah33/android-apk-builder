# Aviator AI Live Analyzer v12 — Outstanding Intelligence Upgrade

This release is based on the latest v11 source project. It removes any RNG-prediction claim and treats all outputs as statistical analysis, simulation, and data-quality diagnostics.

## Included
- Live rendered-page capture and public-source fetching with deduplication/stale-data protection
- Adaptive online model + nearest-pattern model + robust median baseline
- Ensemble agreement and adaptive confidence
- Explicit NO RELIABLE SIGNAL state
- Rolling backtesting, MAE, median error, calibration and anomaly scoring
- Regime/volatility detection and low/high streak analysis
- Distribution, quartiles, robust MAD and volatility dashboard
- Session health and data-quality monitoring
- Replay/backtest mode
- 100-round synthetic simulation mode, clearly separated from real history
- Local persistence for up to 1,000 rounds
- CSV export/share of history
- SHA-256 local dataset fingerprint and comparison helper for official commitments/hashes when a game exposes them
- Login/account access inside the app WebView (subject to the website's normal authentication/anti-bot controls)
- Low-dependency, portrait Android UI suitable for low-end devices

## Important
The app does not claim to know the next random crash result and does not bypass protected/private APIs or anti-bot systems. Statistical patterns can fail, especially for independently generated outcomes.

## Build
Use `build_apk.sh` with the Android toolchain expected by the APK-builder setup, for example:

`TOOLCHAIN=/path/to/toolchain ./build_apk.sh AviatorAI_LiveAnalyzer_v12_Outstanding.apk`
