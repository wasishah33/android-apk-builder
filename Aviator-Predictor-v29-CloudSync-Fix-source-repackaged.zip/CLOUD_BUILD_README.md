# Aviator Predictor v29 — Cloud Sync Fix

This archive contains the Version 29 Android source project, including the welcome screen and cloud-sync fix. It is a source archive, not an APK.

## Build requirements
- JDK 17
- Gradle 8.9 (Android Gradle Plugin 8.7.3)
- Android SDK platform 35 and build-tools 35.0.0

## Build
From this directory run `gradle --no-daemon --stacktrace assembleDebug`. The debug APK should be created at `build/outputs/apk/debug/`.

The app uses package/application ID `com.aviator.live`, version code 29, and version name `29.0-Welcome-Splash`. Real-device testing is still required, including OCR history extraction and Supabase/cloud synchronization.
