# Aviator Predictor v29 — cloud synchronization repair

## What changed in this source package
- Added authenticated `aviator-sync` Edge Function (deployed to the configured Supabase project as version 2).
- The Android client downloads the canonical, cross-device-validated round dataset and active model metadata on startup and periodically while open.
- Shared rounds are stored separately from this device's chronological game history; they are not inserted into the local round sequence where ordering could be misleading.
- Prediction snapshots and scored outcomes are uploaded to `aviator-ingest` in idempotent batches. Server uniqueness constraints make retries safe.
- Pending OCR observations remain in the durable local queue; the previous 500-item truncation was removed so offline data is not silently discarded.
- Cloud retry checks run periodically while the app is open, so reconnecting does not require a new OCR round to trigger synchronization.
- Fixed client parsing of `aviator-ingest`'s nested `inserted` / `duplicates_ignored` response fields.
- Updated app/build version metadata to 29.0-Welcome-Splash-CloudSync. The welcome screen credit remains unchanged.

## Shared-learning policy
- Raw observations are not training data merely because one device reported them.
- The current backend marks a multiplier accepted for shared learning only after independent device observations corroborate it within the configured tolerance and time window.
- Scored prediction snapshots/outcomes are uploaded separately and can be used by the backend's shared band-calibration evaluation. This does not establish that the game is predictable or guarantee future results.
- The client never contains the Supabase service-role secret. The new sync endpoint requires a valid authenticated Supabase session and uses the service role only server-side.

## Important test status
The Edge Function deployment was confirmed active. This workspace has no Android SDK platform 35 or Gradle installation, and outbound DNS is unavailable, so the APK cannot be compiled here and a real two-phone online/offline test has not yet been performed. Before distributing an APK, build it with the included GitHub Actions workflow and test two devices: duplicate retry, offline queue/reconnect, shared accepted-round download, invalid/expired auth, and consistent prediction/outcome counts.
