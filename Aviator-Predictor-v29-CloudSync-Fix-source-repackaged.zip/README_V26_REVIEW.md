# Aviator Predictor v26 — source review changes

This source revision implements the requested UI/OCR/analysis corrections before producing a new APK.

- Restores control panel (OPEN / CRAWL URL / RECONNECT and scan controls) above the game WebView, with Live Analysis below it.
- Uses a red, black, and white sports palette.
- Separates OCR history candidates from the large live multiplier by font-size-aware row clustering; history candidates must be smaller than and above the prominent live-multiplier line.
- Seeds the learner from the first visible completed-round history row when local history is empty.
- Keeps raw URL-crawler values diagnostic-only because raw HTML parsing cannot reliably distinguish a live multiplier from a completed result.
- Makes the Live Analysis panel stable with fixed-height, single-line text rows and removes the watchdog's writes to prediction text.
- Displays a history-derived statistical estimate band after five completed rounds, independently of the current live multiplier.
- Speeds online model updates (learning rate 0.04) and persists each accepted update.

Important: crash-game outcomes are random. The estimate band is a historical statistical summary, not a reliable or guaranteed next-round prediction. This source has passed a lightweight delimiter check, but it has not yet been built into an APK or tested on the user's device. Build is intentionally pending review.
