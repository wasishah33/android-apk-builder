import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
const headers={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json"};
function reply(status:number,body:Record<string,unknown>){return new Response(JSON.stringify(body),{status,headers});}
function isUuid(v:unknown):boolean{return typeof v==="string"&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);}
Deno.serve(async(req:Request)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers});
 if(req.method!=="POST")return reply(405,{error:"method_not_allowed"});
 const url=Deno.env.get("SUPABASE_URL"),anon=Deno.env.get("SUPABASE_ANON_KEY"),service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
 if(!url||!anon||!service)return reply(500,{error:"backend_configuration_missing"});
 const auth=(req.headers.get("Authorization")??"").match(/^Bearer\s+(.+)$/),token=auth?.[1]??"";
 if(!token)return reply(401,{error:"bearer_token_required"});
 const authClient=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}});
 const {data:userData,error:userError}=await authClient.auth.getUser(token);
 if(userError||!userData.user)return reply(401,{error:"invalid_session"});
 let body:any;try{body=await req.json();}catch{return reply(400,{error:"invalid_json"});}
 if(!isUuid(body?.device_id))return reply(400,{error:"device_id_must_be_uuid"});
 const db=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});
 const {data:device,error:deviceError}=await db.from("aviator_device_sync_state").select("auth_user_id").eq("device_id",body.device_id).maybeSingle();
 if(deviceError)return reply(500,{error:"device_binding_lookup_failed"});
 if(device?.auth_user_id&&device.auth_user_id!==userData.user.id)return reply(403,{error:"device_already_bound_to_another_auth_session"});
 const {data:rounds,error:roundError}=await db.from("aviator_round_outcomes").select("round_key,multiplier,first_observed_at,last_observed_at,observation_count,confidence_mean,validation_status").eq("validation_status","accepted").order("first_observed_at",{ascending:false}).limit(500);
 if(roundError)return reply(500,{error:"shared_rounds_read_failed"});
 const {count:totalRounds,error:countError}=await db.from("aviator_round_outcomes").select("id",{count:"exact",head:true}).eq("validation_status","accepted");
 if(countError)return reply(500,{error:"shared_round_count_failed"});
 const {data:models,error:modelError}=await db.from("aviator_model_versions").select("model_name,version_label,model_type,artifact,metrics,training_rows,created_at").eq("is_active",true).order("created_at",{ascending:false}).limit(20);
 if(modelError)return reply(500,{error:"shared_model_read_failed"});
 const {data:state,error:stateError}=await db.from("aviator_device_sync_state").select("last_successful_sync_at,submitted_count,accepted_count").eq("device_id",body.device_id).maybeSingle();
 if(stateError)return reply(500,{error:"sync_state_read_failed"});
 return reply(200,{ok:true,shared_rounds:rounds??[],shared_round_count:totalRounds??0,downloaded_round_count:(rounds??[]).length,models:models??[],device:{last_successful_sync_at:state?.last_successful_sync_at??null,submitted_count:state?.submitted_count??0,accepted_count:state?.accepted_count??0},sync_server_time:new Date().toISOString(),note:"Only cross-device corroborated accepted rounds are returned; shared observations remain separate from local sequential history."});
});
