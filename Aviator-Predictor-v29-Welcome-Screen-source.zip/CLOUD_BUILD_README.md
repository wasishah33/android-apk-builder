# Aviator Predictor v25 — cloud build

The GitHub Actions workflow builds a debug APK using Java 17, Gradle 8.9 and Android SDK 35, then uploads it as a workflow artifact. This archive is a source/build package; it is not itself an APK.

The project has not been compiled in this environment because Android SDK platform 35 and Gradle are not installed. After a successful remote build, install and test on an Android device. Verify PixelCopy capture while the actual game iframe is visible, OCR history-row diagnostics, no duplicate history insertion, anonymous Auth, and successful `aviator-ingest` uploads.


Version 25 adds hybrid capture: PixelCopy as primary, periodic WebView.draw cross-check, immediate draw fallback when PixelCopy fails, plus existing DOM/iframe extraction. It also refreshes the UI with a green/lime, red, yellow, and charcoal sports-game palette and an original aircraft-inspired launcher icon. Real-device OCR and backend upload testing are still required.
