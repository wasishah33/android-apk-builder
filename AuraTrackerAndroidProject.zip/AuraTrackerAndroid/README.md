# Aura Tracker — Android Project

A single-page Android WebView app based on the uploaded Aura Tracker PRD.

## Features
- Home-only interface, no bottom navigation
- Date strip from 60 days before today through 90 days after today
- Add/edit/delete habits by date, icon picker (48 icons), categories, time, priority, notes
- All / Pending / Done filters and live daily progress
- Mark completed habits; future-date habits cannot be checked off
- Weekly stats popup with Monday–Sunday bars and per-habit completion
- Local persistence using `localStorage` key `auraTracker.v1`
- Works offline after the project is installed; uses system fonts and emoji so no CDN is required

## Open and run
1. Install Android Studio.
2. Choose **Open** and select this `AuraTrackerAndroid` folder.
3. Let Gradle sync finish (Android SDK Platform 35 required; Android Studio can install it).
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**.

## Build an APK
In Android Studio, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is usually generated under `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The app stores data on this device only; no account or cloud sync.
- Uninstalling or clearing app storage can remove local habit data.
- The Android wrapper is a WebView project. This package is source code, not a prebuilt APK.
- Built against Android Gradle Plugin 8.7.3 and compile SDK 35.
